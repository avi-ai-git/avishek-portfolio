# AV.AI Brand Concept

## Core identity

AV.AI is the personal creative technology portfolio of Avishek Chatterjee, an AI Creative Technologist based in Berlin.

AV.AI should not feel like a generic AI startup or a fake agency. It should feel like a personal visual systems lab: experimental, cinematic, terminal-born, but still clear and professional enough for recruiters, agencies, AI product teams, and creative technology teams.

## Meaning of the name

- AV = Avishek / audio-visual
- AI = artificial intelligence
- The red dot = signal, cursor, pulse, recording light, active system state
- ASCII / terminal language = machine interface, creative systems, code, visual intelligence, AI workflows

The identity should connect the brand mark AV.AI directly to Avishek Chatterjee.

## Hero identity rule

The first screen should clearly show:

AV.AI  
Avishek Chatterjee  
AI Creative Technologist · Berlin

This is important because AV.AI is a personal identity, not a company.

## Visual direction

Dark terminal interface meets premium editorial portfolio.

The homepage and interactive sections should use a dark terminal-inspired interface with ASCII forms, scanlines, red cursor details, hover states, and cinematic spacing.

The case-study sections should shift into a warmer editorial mode so the work remains readable and recruiter-friendly.

## Color palette

- Near-black background: #0B0B0A
- Deep charcoal: #151514
- Off-white text: #F2F0E8
- Muted grey metadata: #8A8880
- Thin charcoal dividers: #2A2926
- Signal red accent: #FF2A1F
- Warm off-white editorial background: #EDE8DD

Use signal red only for the dot in AV.AI, cursor blink, active states, and small emphasis moments. Do not overuse red.

## Typography direction

- Large headlines: Archivo Black or Space Grotesk
- Navigation, metadata, labels, terminal copy, and ASCII elements: IBM Plex Mono
- Body copy: Inter or IBM Plex Sans

The typography should feel precise, technical, and premium. Avoid overly futuristic sci-fi fonts.

## Logo direction

The logo is a pure typographic wordmark:

AV.AI

The dot between AV and AI is the signature red signal element.

Do not add icons, symbols, robot imagery, brain imagery, abstract AI symbols, decorative marks, or generic AI graphics. Keep the logo typographic, bold, minimal, and precise.

## Site structure

1. Dark terminal hero
   - Large AV.AI wordmark
   - Avishek Chatterjee
   - AI Creative Technologist · Berlin
   - Short positioning statement
   - ASCII visual field or signal form
   - Red cursor/pulse detail

2. Selected work index
   - Typographic project rows
   - Hover previews
   - Small metadata labels
   - Clear outcomes

3. Capabilities
   - AI Creative Workflows
   - Visual Storytelling
   - Workshop and Learning Design
   - Content Systems and Knowledge Hubs

4. Featured immersive project
   - Fractal Breaths as a dark interactive/product-style section
   - Breathing orb or ASCII waveform
   - Controls for inhale, hold, exhale, rest, visual pattern, and soundscape

5. Editorial case studies
   - Warm off-white background
   - Clear problem/process/outcome structure
   - Recruiter-friendly explanation

6. Proof section
   - AI short film selected for Artefact AI Film Festival Paris
   - Designed and delivered first GenAI Bootcamp at HIKE Nordhausen
   - GIZ LMS redesign improved engagement by approximately 30%
   - Built communications and knowledge systems across campaigns, events, video, and Notion

7. Contact
   - Dark terminal style
   - Headline: > SEND SIGNAL
   - Contact links and availability statement

## Interaction style

Use:
- subtle scanlines
- ASCII forms
- hover previews
- red cursor pulse
- smooth transitions
- light terminal motion

Avoid:
- heavy glitch effects
- unreadable animations
- long loading screens
- generic AI gradients
- glassmorphism
- robot/brain icons
- crypto/Web3 aesthetics
- corporate SaaS visuals
- stock technology imagery

## Final desired feeling

AV.AI should feel like a dark terminal-born creative technology portfolio with ASCII visuals, red signal accents, and clean editorial case studies. It should be original and memorable, but still easy to understand.
